package com.tma.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tma.dao.DeviceDAO;
import com.tma.entities.Device;
import com.tma.service.DeviceService;

@Service("deviceService")
@Transactional
public class DeviceServiceImpl implements DeviceService{
	
	@Autowired
	private DeviceDAO deviceDao;
	
	@Override
	public void create(Device device) {
		// TODO Auto-generated method stub
		deviceDao.create(device);
	}

	@Override
	public void remove(Device device) {
		// TODO Auto-generated method stub
		deviceDao.remove(device);
	}

	@Override
	public void edit(Device device) {
		// TODO Auto-generated method stub
		deviceDao.edit(device);
	}

	@Override
	public List<Device> findAll() {
		// TODO Auto-generated method stub
		return deviceDao.findAll();
	}

	@Override
	public Device find(int id) {
		// TODO Auto-generated method stub
		return deviceDao.find(id);
	}

	@Override
	public List<Device> findAllAvailable() {
		// TODO Auto-generated method stub
		return deviceDao.findAllAvailable();
	}

	@Override
	public void setStatusDevice(String nameDevice, String status) {
		// TODO Auto-generated method stub
		deviceDao.setStatusDevice(nameDevice, status);
	}

	@Override
	public Device getStatusDevice(String nameDevice) {
		// TODO Auto-generated method stub
		return deviceDao.getStatusDevice(nameDevice);
	}
}
