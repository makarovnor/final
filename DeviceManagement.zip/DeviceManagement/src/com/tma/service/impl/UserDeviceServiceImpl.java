package com.tma.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tma.dao.UserDeviceDAO;
import com.tma.entities.UserDevice;
import com.tma.service.UserDeviceService;

@Service("userDeviceService")
@Transactional
public class UserDeviceServiceImpl implements UserDeviceService {

	@Autowired
	private UserDeviceDAO userDeviceDAO;
	
	@Override
	public void create(UserDevice userDevice) {
		// TODO Auto-generated method stub
		userDeviceDAO.create(userDevice);
	}

	@Override
	public void edit(UserDevice userDevice) {
		// TODO Auto-generated method stub
		userDeviceDAO.edit(userDevice);
	}

	@Override
	public UserDevice findByUsernameAndNameDevice(String username, String nameDevice){
		// TODO Auto-generated method stub
		return userDeviceDAO.findByUsernameAndNameDevice(username, nameDevice);
	}

	@Override
	public List<UserDevice> findByStatus(String status) {
		// TODO Auto-generated method stub
		return userDeviceDAO.findByStatus(status);
	}

	@Override
	public List<UserDevice> findAll() {
		// TODO Auto-generated method stub
		return userDeviceDAO.findAll();
	}

	@Override
	public List<UserDevice> getHistoryRequest(String username) {
		// TODO Auto-generated method stub
		return userDeviceDAO.getHistoryRequest(username);
	}

	@Override
	public List<UserDevice> getBorrow() {
		// TODO Auto-generated method stub
		return userDeviceDAO.getBorrow();
	}

	@Override
	public UserDevice findById(int id) {
		// TODO Auto-generated method stub
		return userDeviceDAO.findById(id);
	}

	@Override
	public List<UserDevice> getAllRequest() {
		// TODO Auto-generated method stub
		return userDeviceDAO.getAllRequest();
	}

	@Override
	public UserDevice findByNameDeviceWithAPRROVE(String nameDevice) {
		// TODO Auto-generated method stub
		return userDeviceDAO.findByNameDeviceWithAPRROVE(nameDevice);
	}
	
}
