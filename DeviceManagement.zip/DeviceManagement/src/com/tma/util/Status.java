package com.tma.util;

public final class Status {
	public static final String REQUEST = "REQUEST";
	
	public static final String APPROVE = "APPROVE";
	
	public static final String REJECT = "REJECT";
	
	public static final String BORROW = "BORROW";
	
	public static final String RETURN = "RETURN";
	
	public static final String AVAILABLE = "AVAILABLE";
	
	public static final String UNAVAILABLE = "UNAVAILABLE";
}
