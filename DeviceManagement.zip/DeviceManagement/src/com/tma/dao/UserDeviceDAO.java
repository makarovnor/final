package com.tma.dao;

import java.util.List;

import com.tma.entities.UserDevice;

public interface UserDeviceDAO {
	public void create(UserDevice userDevice);
	public void edit(UserDevice userDevice);
	public UserDevice findById(int id);
	public UserDevice findByNameDeviceWithAPRROVE(String nameDevice);
	public UserDevice findByUsernameAndNameDevice(String username, String nameDevice);
	public List<UserDevice> findByStatus(String status);
	public List<UserDevice> findAll();
	public List<UserDevice> getAllRequest();
	public List<UserDevice> getHistoryRequest(String username);
	public List<UserDevice> getBorrow();
}
 