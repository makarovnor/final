package com.tma.dao;

import java.util.List;

import com.tma.entities.UserDevice;

public interface UserDeviceDAO {
	public void create(UserDevice userDevice);
	
	public void edit(UserDevice userDevice);
	public void updateNameDevice(String oldName, String newName);
	public void updateUsername(String oldName, String newName);
	
	public UserDevice findById(int id);
	public List<UserDevice> findByNameDevice(String nameDevice);
	public List<UserDevice> findByUsername(String username);
	public UserDevice findByNameDeviceWithAPRROVE(String nameDevice);
	public UserDevice findByUsernameAndNameDevice(String username, String nameDevice);
	public List<UserDevice> findByStatus(String status);
	public List<UserDevice> findAll();
	
	public List<UserDevice> getAllRequest();
	public List<UserDevice> getHistoryRequest(String username);
	public List<UserDevice> getBorrow();
}
 