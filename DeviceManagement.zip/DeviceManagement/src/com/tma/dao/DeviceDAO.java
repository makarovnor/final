package com.tma.dao;

import java.util.List;

import com.tma.entities.Device;

public interface DeviceDAO {
	public void create(Device device);
	public void remove(Device device);
	public void edit(Device device);
    
	public List<Device> findAll();
    public List<Device> findAllAvailable();
    
    public Device find(int id);
    public void setStatusDevice(String nameDevice, String status);
    public Device getStatusDevice(String nameDevice );
}
