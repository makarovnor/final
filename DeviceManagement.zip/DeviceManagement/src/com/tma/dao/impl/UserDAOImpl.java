package com.tma.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tma.dao.UserDAO;
import com.tma.entities.User;

@Repository("userDAO")
public class UserDAOImpl implements  UserDAO{
	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public void create(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@Override
	public void remove(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().delete(user);

	}

	@Override
	public void edit(User user) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(User.class).list();
	}

	@Override
	public User find(int id) {
		// TODO Auto-generated method stub
		return (User) sessionFactory.getCurrentSession().get(User.class, id);
	}

}
