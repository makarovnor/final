package com.tma.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tma.dao.UserDeviceDAO;
import com.tma.entities.UserDevice;
import com.tma.util.Status;

@Repository("userDeviceDAO")
public class UserDeviceDAOImpl implements UserDeviceDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void create(UserDevice userDevice) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().persist(userDevice);
	}

	@Override
	public void edit(UserDevice userDevice) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(userDevice);
	}

	@Override
	public UserDevice findById(int id) {
		// TODO Auto-generated method stub
		return (UserDevice) sessionFactory.getCurrentSession().get(UserDevice.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserDevice findByUsernameAndNameDevice(String username, String nameDevice) {
		// TODO Auto-generated method stub
		List<UserDevice> listUserDevice = sessionFactory.getCurrentSession()
				.createQuery("FROM UserDevice u WHERE u.username = :username AND u.nameDevice = :nameDevice")
				.setParameter("username", username).setParameter("nameDevice", nameDevice).list();
		if (listUserDevice.isEmpty()) {
			return null;
		}
		return listUserDevice.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> findByStatus(String status) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("FROM UserDevice u WHERE u.status =:status")
				.setParameter("status", status).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> findAll() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createCriteria(UserDevice.class).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> getHistoryRequest(String username) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession()
				.createQuery(
						"FROM UserDevice u WHERE u.username =:username AND (u.status =:status1 OR u.status =:status2 OR u.status =:status3)")
				.setParameter("username", username).setParameter("status1", Status.REQUEST)
				.setParameter("status2", Status.APPROVE).setParameter("status3", Status.REJECT).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> getBorrow() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession()
				.createQuery("from UserDevice u where u.status =:status1 OR u.status =:status2 OR u.status =:status3")
				.setParameter("status1", Status.APPROVE).setParameter("status2", Status.BORROW)
				.setParameter("status3", Status.RETURN).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> getAllRequest() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession()
				.createQuery("from UserDevice u where u.status =:status1 OR u.status =:status2 OR u.status =:status3")
				.setParameter("status1", Status.REQUEST).setParameter("status2", Status.APPROVE)
				.setParameter("status3", Status.REJECT).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserDevice findByNameDeviceWithAPRROVE(String nameDevice) {
		// TODO Auto-generated method stub
		List<UserDevice> listUserDevice = sessionFactory.getCurrentSession()
				.createQuery("FROM UserDevice u WHERE u.nameDevice = :nameDevice AND u.status = :status")
				.setParameter("nameDevice", nameDevice).setParameter("status", Status.APPROVE).list();
		if (listUserDevice.isEmpty()) {
			return null;
		}
		return listUserDevice.get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> findByNameDevice(String nameDevice) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("FROM UserDevice u where u.nameDevice = :nameDevice")
				.setParameter("nameDevice", nameDevice).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserDevice> findByUsername(String username) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("FROM UserDevice u where u.username = :username")
				.setParameter("username", username).list();
	}

	@Override
	public void updateNameDevice(String oldName, String newName) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession()
				.createQuery("UPDATE UserDevice u SET u.nameDevice = :newName WHERE u.nameDevice = :oldName")
				.setParameter("newName", newName).setParameter("oldName", oldName).executeUpdate();
	}

	@Override
	public void updateUsername(String oldName, String newName) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession()
				.createQuery("UPDATE UserDevice u SET u.username = :newName WHERE u.username = :oldName")
				.setParameter("newName", newName).setParameter("oldName", oldName).executeUpdate();
	}

	@Override
	public void deleteByUsername(String username) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().createQuery("DELETE FROM UserDevice u WHERE u.username = :username")
				.setParameter("username", username).executeUpdate();
	}

	@Override
	public void deleteByNameDevice(String nameDevice) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().createQuery("DELETE FROM UserDevice u WHERE u.nameDevice = :nameDevice")
				.setParameter("nameDevice", nameDevice).executeUpdate();
	}

}
