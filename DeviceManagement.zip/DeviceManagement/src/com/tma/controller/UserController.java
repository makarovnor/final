package com.tma.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tma.entities.User;
import com.tma.service.UserService;
import com.tma.validator.UserValidator;

@Controller
@RequestMapping(value = "/user**")
public class UserController {

	@Autowired(required = true)
	private UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listUser", userService.findAll());
		return "listUser";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("user", new User());
		return "addUser";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "user") @Valid User user, BindingResult bindingResult) {
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addUser";
		} else {
			userService.create(user);
			return "redirect:/user.html";
		}
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		userService.remove(userService.find(id));
		return "redirect:/user.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("user", userService.find(id));
		return "editUser";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "user") @Valid User user, BindingResult bindingResult) {
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			return "editUser";
		} else {
			userService.edit(user);
			return "redirect:/user.html";
		}
	}
}

