package com.tma.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.tma.entities.UserDevice;
import com.tma.service.DeviceService;
import com.tma.service.UserDeviceService;
import com.tma.util.Status;

@Controller
@RequestMapping(value = "/manage")
public class UserDeviceController {

	@Autowired
	private UserDeviceService userDeviceService;

	@Autowired
	private DeviceService deviceService;

	// Resquest Device
	@RequestMapping(value = "/requestDevice", method = RequestMethod.GET)
	public String requestDevice(ModelMap modelMap) {
		modelMap.addAttribute("userDevice", new UserDevice());
		modelMap.addAttribute("listDevice", deviceService.findAllAvailable());
		return "requestDevice";
	}

	@RequestMapping(value = "/requestDevice", method = RequestMethod.POST)
	public String requestDevice(@ModelAttribute(value = "userDevice") UserDevice userDevice) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		
		userDevice.setUsername(userDetail.getUsername());
		userDevice.setRequestDate(new Date());
		userDevice.setStatus(Status.REQUEST);

		UserDevice userDeviceTemp = userDeviceService.findByUsernameAndNameDevice(userDetail.getUsername(),
				userDevice.getNameDevice());
		
		if (userDeviceTemp != null) {
			if (userDevice.getUsername().equals(userDeviceTemp.getUsername())
					&& userDevice.getNameDevice().equals(userDeviceTemp.getNameDevice())) {
				userDevice.setApproveDate(null);
				userDevice.setBorrowDate(null);
				userDevice.setReturnDate(null);
				userDevice.setId(userDeviceTemp.getId());
				userDeviceService.edit(userDevice);
				return "welcome";
			}
		}
		userDeviceService.create(userDevice);
		return "welcome";
	}

	// Process request by Admin
	@RequestMapping(value = "/listRequest", method = RequestMethod.GET)
	public String listRequest(ModelMap modelMap) {
		modelMap.addAttribute("listRequest", userDeviceService.getAllRequest());
		return "listRequest";
	}

	@RequestMapping(value = "/processRequest/{id}", method = RequestMethod.GET)
	public String processRequest(@PathVariable(value = "id") int id, ModelMap modelMap) {
		if (userDeviceService.findById(id) == null) {
			return "403";
		}
		modelMap.addAttribute("userDevice", userDeviceService.findById(id));
		return "processRequest";
	}

	@RequestMapping(value = "/processRequest", method = RequestMethod.POST)
	public String processRequest(@ModelAttribute(value = "userDevice") UserDevice userDevice, ModelMap modelMap) {
		userDevice.setApproveDate(new Date());
		if (userDevice.getStatus().equals(Status.APPROVE)
				&& deviceService.getStatusDevice(userDevice.getNameDevice()).getStatus().equals(Status.AVAILABLE)) {
			deviceService.setStatusDevice(userDevice.getNameDevice(), Status.UNAVAILABLE);
			userDeviceService.edit(userDevice);

		} else if (userDevice.getStatus().equals(Status.APPROVE)
				&& deviceService.getStatusDevice(userDevice.getNameDevice()).getStatus().equals(Status.UNAVAILABLE)) {
			if (!userDeviceService.findByNameDeviceWithAPRROVE(userDevice.getNameDevice()).getUsername()
					.equals(userDevice.getUsername())) {
				modelMap.put("message", "You approved " + userDevice.getNameDevice() + " for "
						+ userDeviceService.findByNameDeviceWithAPRROVE(userDevice.getNameDevice()).getUsername());
				return "processRequest";
			}
			userDeviceService.edit(userDevice);

		} else if (userDevice.getStatus().equals(Status.REJECT)
				&& deviceService.getStatusDevice(userDevice.getNameDevice()).getStatus().equals(Status.UNAVAILABLE)) {
			if (userDeviceService.findByNameDeviceWithAPRROVE(userDevice.getNameDevice()).getUsername()
					.equals(userDevice.getUsername())) {
				deviceService.setStatusDevice(userDevice.getNameDevice(), Status.AVAILABLE);
			}
			userDeviceService.edit(userDevice);
		} else {
			userDeviceService.edit(userDevice);
		}
		return "redirect:/manage/listRequest.html";
	}

	// View history request by Employee
	@RequestMapping(value = "/historyRequest", method = RequestMethod.GET)
	public String historyRequest(ModelMap modelMap) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetail = (UserDetails) authentication.getPrincipal();
		modelMap.addAttribute("historyRequest", userDeviceService.getHistoryRequest(userDetail.getUsername()));
		return "historyRequest";
	}

	// View All Log
	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listUserDevice", userDeviceService.findAll());
		return "listUserDevice";
	}

	// Processing Borrow/Return
	@RequestMapping(value = "/listBorrow", method = RequestMethod.GET)
	public String listBorrow(ModelMap modelMap) {      
		modelMap.addAttribute("listBorrow", userDeviceService.getBorrow());
		return "listBorrow";
	}

	@RequestMapping(value = "/manageBorrow/{id}", method = RequestMethod.GET)
	public String manageBorrow(@PathVariable(value = "id") int id, ModelMap modelMap) {
		modelMap.addAttribute("userDevice", userDeviceService.findById(id));
		return "manageBorrow";
	}

	@RequestMapping(value = "/manageBorrow", method = RequestMethod.POST)
	public String manageBorrow(@ModelAttribute(value = "userDevice") UserDevice userDevice, ModelMap modelMap) {
		if (userDevice.getStatus().equals(Status.RETURN)) {
			if(userDevice.getBorrowDate() == null){
				modelMap.put("message", "Device is not borrowed");
				return "manageBorrow";
			}
			userDevice.setReturnDate(new Date());
			deviceService.setStatusDevice(userDevice.getNameDevice(), Status.AVAILABLE);
		}
		if (userDevice.getStatus().equals(Status.BORROW)) {
			userDevice.setBorrowDate(new Date());
		}
		userDeviceService.edit(userDevice);
		return "redirect:/manage/listBorrow.html";
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
}
