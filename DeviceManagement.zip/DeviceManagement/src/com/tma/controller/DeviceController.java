package com.tma.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.tma.entities.Device;
import com.tma.service.DeviceService;
import com.tma.service.UserDeviceService;
import com.tma.validator.DeviceValidator;

@Controller
@RequestMapping(value = "/device**")
public class DeviceController {

	@Autowired(required = true)
	private DeviceService deviceService;
	
	@Autowired
	private UserDeviceService userDeviceService;

	@RequestMapping(method = RequestMethod.GET)
	public String index(ModelMap modelMap) {
		modelMap.addAttribute("listDevice", deviceService.findAll());
		return "listDevice";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		modelMap.addAttribute("device", new Device());
		return "addDevice";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "device") @Valid Device device, BindingResult bindingResult) {
		DeviceValidator deviceValidator = new DeviceValidator();
		deviceValidator.validate(device, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addDevice";
		} else {
			deviceService.create(device);
			return "redirect:/device.html";
		}
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") int id) {
		deviceService.remove(deviceService.find(id));
		return "redirect:/device.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") int id, ModelMap modelMap) {
		if (deviceService.find(id) == null) {
			return "403";
		}
		modelMap.addAttribute("device", deviceService.find(id));
		modelMap.addAttribute("nameDevice", deviceService.find(id).getName());
		return "editDevice";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "device") @Valid Device device, BindingResult bindingResult, @RequestParam(value = "nameDevice") String nameDevice) {
		DeviceValidator deviceValidator = new DeviceValidator();
		deviceValidator.validate(device, bindingResult);
		if (bindingResult.hasErrors()) {
			return "editDevice";
		} else {
			userDeviceService.updateNameDevice(nameDevice, device.getName());
			deviceService.edit(device);
			return "redirect:/device.html";
		}
	}
}

